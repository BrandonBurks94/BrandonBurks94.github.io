const express = require('express');
const router = express.Router();

const authController = require('../controllers/authentication');
const tripsController = require('../controllers/trips');
const { authenticateJWT } = require('../middleware/authentication');

router.post('/register', authController.register);
router.post('/login', authController.login);

router.get('/trips', tripsController.tripsList);
router.get('/trips/recommendations', tripsController.tripsRecommend);
router.post('/trips', authenticateJWT, tripsController.tripsAddTrip);
router.get('/trips/:tripCode', tripsController.tripsFindByCode);
router.put('/trips/:tripCode', authenticateJWT, tripsController.tripsUpdateTrip);
router.delete('/trips/:tripCode', authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;
