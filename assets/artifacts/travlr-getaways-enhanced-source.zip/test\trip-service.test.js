const test = require('node:test');
const assert = require('node:assert/strict');

const createTripService = require('../app_api/services/trip-service');

const trip = {
  code: 'GALE-REEF',
  name: 'Gale Reef',
  image: 'reef1.jpg',
  duration: '4 nights',
  price: '$799',
  description: 'Featured reef trip',
  details: 'Guided reef travel package'
};

test('trip service returns a trip by code through the repository boundary', async () => {
  const repository = {
    async findByCode(code) {
      assert.equal(code, 'GALE-REEF');
      return trip;
    }
  };
  const service = createTripService(repository);

  assert.deepEqual(await service.getTripByCode(' GALE-REEF '), trip);
});

test('trip service delegates recommendation criteria after loading trips', async () => {
  const repositoryTrips = [trip];
  const repository = {
    async findForRecommendationCriteria(criteria) {
      assert.deepEqual(criteria, {
        maxPrice: null,
        maxNights: null,
        limit: 10,
        tokens: ['reef']
      });
      return repositoryTrips;
    }
  };
  const recommendationService = {
    normalizeCriteria(criteria) {
      assert.deepEqual(criteria, { query: 'reef' });
      return {
        maxPrice: null,
        maxNights: null,
        limit: 10,
        tokens: ['reef']
      };
    },
    recommend(trips, criteria) {
      assert.equal(trips, repositoryTrips);
      assert.deepEqual(criteria.tokens, ['reef']);
      return [{ ...trip, recommendationScore: 8 }];
    }
  };
  const service = createTripService(repository, recommendationService);

  const results = await service.recommendTrips({ query: 'reef' });

  assert.equal(results[0].recommendationScore, 8);
});

test('trip service maps missing trips to 404 errors', async () => {
  const service = createTripService({
    async findByCode() {
      return null;
    }
  });

  await assert.rejects(
    () => service.getTripByCode('MISSING'),
    (err) => err.statusCode === 404 && /MISSING/.test(err.message)
  );
});

test('trip service validates and trims create payloads before persistence', async () => {
  const repository = {
    async create(payload) {
      assert.equal(payload.code, 'GALE-REEF');
      assert.equal(payload.name, 'Gale Reef');
      return payload;
    }
  };
  const service = createTripService(repository);

  const result = await service.addTrip({ ...trip, code: ' GALE-REEF ', name: ' Gale Reef ' });

  assert.equal(result.code, 'GALE-REEF');
  assert.equal(result.name, 'Gale Reef');
});

test('trip service maps duplicate trip codes to conflict errors', async () => {
  const repository = {
    async create() {
      const err = new Error('duplicate key');
      err.code = 11000;
      throw err;
    }
  };
  const service = createTripService(repository);

  await assert.rejects(
    () => service.addTrip(trip),
    (err) => err.statusCode === 409 && /already exists/.test(err.message)
  );
});
