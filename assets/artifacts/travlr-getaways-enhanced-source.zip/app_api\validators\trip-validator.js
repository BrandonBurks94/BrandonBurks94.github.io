const HttpError = require('../errors/http-error');
const {
  buildTripStorageFields,
  parseMoney,
  parseNights
} = require('../utils/trip-normalization');

const requiredTripFields = [
  'code',
  'name',
  'image',
  'duration',
  'price',
  'description',
  'details'
];

const isBlank = (value) => typeof value !== 'string' || !value.trim();

const buildTripPayload = (body) => {
  const payload = requiredTripFields.reduce((fields, field) => {
    fields[field] = body[field].trim();
    return fields;
  }, {});

  return {
    ...payload,
    ...buildTripStorageFields(payload)
  };
};

const validateTripPayload = (body = {}) => {
  const missingFields = requiredTripFields.filter((field) => isBlank(body[field]));

  if (missingFields.length) {
    throw new HttpError(
      400,
      'Missing required trip fields',
      { fields: missingFields }
    );
  }

  if (parseMoney(body.price) === null) {
    throw new HttpError(400, 'Trip price must contain a numeric amount');
  }

  if (parseNights(body.duration) === null) {
    throw new HttpError(400, 'Trip duration must contain a numeric night count');
  }
};

const validateTripCode = (tripCode) => {
  if (isBlank(tripCode)) {
    throw new HttpError(400, 'Trip code is required');
  }

  return tripCode.trim();
};

module.exports = {
  requiredTripFields,
  buildTripPayload,
  validateTripPayload,
  validateTripCode
};
