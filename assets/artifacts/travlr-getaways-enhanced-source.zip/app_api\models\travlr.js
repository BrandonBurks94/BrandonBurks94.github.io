const mongoose = require('mongoose');
const {
  buildSearchText,
  normalizeTripCode,
  parseMoney,
  parseNights
} = require('../utils/trip-normalization');

const tripSchema = new mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    uppercase: true,
    set: normalizeTripCode
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  image: {
    type: String,
    required: true,
    trim: true
  },
  duration: {
    type: String,
    required: true,
    trim: true
  },
  durationNights: {
    type: Number,
    required: true,
    default() {
      return parseNights(this.duration);
    },
    min: 1,
    validate: {
      validator: Number.isFinite,
      message: 'Trip duration must resolve to a numeric night count'
    }
  },
  price: {
    type: String,
    required: true,
    trim: true
  },
  priceAmount: {
    type: Number,
    required: true,
    default() {
      return parseMoney(this.price);
    },
    min: 0,
    validate: {
      validator: Number.isFinite,
      message: 'Trip price must resolve to a numeric amount'
    }
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  details: {
    type: String,
    required: true,
    trim: true
  },
  searchText: {
    type: String,
    required: true,
    default() {
      return buildSearchText(this);
    },
    trim: true
  }
}, {
  timestamps: true
});

tripSchema.pre('validate', function deriveDatabaseFields(next) {
  this.code = normalizeTripCode(this.code);
  this.priceAmount = parseMoney(this.price);
  this.durationNights = parseNights(this.duration);
  this.searchText = buildSearchText(this);
  next();
});

tripSchema.index({ code: 1 }, { unique: true });
tripSchema.index({ priceAmount: 1, durationNights: 1 });
tripSchema.index({ searchText: 'text' });

mongoose.model('trips', tripSchema);
