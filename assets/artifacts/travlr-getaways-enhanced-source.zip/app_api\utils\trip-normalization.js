const parseMoney = (value) => {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value;
  }

  if (typeof value !== 'string') {
    return null;
  }

  const normalized = value.replace(/[^0-9.]/g, '');
  if (!normalized) {
    return null;
  }

  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
};

const parseNights = (value) => {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value;
  }

  if (typeof value !== 'string') {
    return null;
  }

  const match = value.match(/\d+(\.\d+)?/);
  return match ? Number(match[0]) : null;
};

const normalizeTripCode = (value) => String(value || '').trim().toUpperCase();

const buildSearchText = (trip = {}) => [
  trip.code,
  trip.name,
  trip.description,
  trip.details
]
  .filter(Boolean)
  .join(' ')
  .toLowerCase();

const buildTripStorageFields = (trip) => ({
  code: normalizeTripCode(trip.code),
  priceAmount: parseMoney(trip.price),
  durationNights: parseNights(trip.duration),
  searchText: buildSearchText(trip)
});

module.exports = {
  parseMoney,
  parseNights,
  normalizeTripCode,
  buildSearchText,
  buildTripStorageFields
};
