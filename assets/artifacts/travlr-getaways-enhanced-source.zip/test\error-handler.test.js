const test = require('node:test');
const assert = require('node:assert/strict');

const HttpError = require('../app_api/errors/http-error');
const { errorHandler } = require('../app_api/middleware/error-handler');

const createResponse = () => {
  const response = {
    statusCode: null,
    body: null,
    headersSent: false,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(body) {
      this.body = body;
      return this;
    }
  };

  return response;
};

test('errorHandler returns validation details for expected client errors', () => {
  const response = createResponse();

  errorHandler(
    new HttpError(400, 'Missing required trip fields', { fields: ['price'] }),
    {},
    response,
    () => {}
  );

  assert.equal(response.statusCode, 400);
  assert.deepEqual(response.body, {
    message: 'Missing required trip fields',
    details: { fields: ['price'] }
  });
});

test('errorHandler hides internal server error details from API callers', () => {
  const originalError = console.error;
  console.error = () => {};
  const response = createResponse();

  try {
    errorHandler(
      new Error('MongoServerError: connection detail that should stay private'),
      {},
      response,
      () => {}
    );
  } finally {
    console.error = originalError;
  }

  assert.equal(response.statusCode, 500);
  assert.deepEqual(response.body, {
    message: 'An unexpected server error occurred'
  });
});
