const test = require('node:test');
const assert = require('node:assert/strict');
const mongoose = require('mongoose');

require('../app_api/models/travlr');

const Trip = mongoose.model('trips');

const trip = {
  code: ' gale-reef ',
  name: 'Gale Reef',
  image: 'reef1.jpg',
  duration: '4 nights',
  price: '$799',
  description: 'Featured reef trip',
  details: 'Guided reef travel package'
};

test('trip schema derives normalized database fields before validation', () => {
  const document = new Trip(trip);
  const validationError = document.validateSync();

  assert.equal(validationError, undefined);
  assert.equal(document.code, 'GALE-REEF');
  assert.equal(document.priceAmount, 799);
  assert.equal(document.durationNights, 4);
  assert.equal(
    document.searchText,
    'GALE-REEF Gale Reef Featured reef trip Guided reef travel package'.toLowerCase()
  );
});

test('trip schema rejects data that cannot populate database query fields', () => {
  const document = new Trip({
    ...trip,
    price: 'free',
    duration: 'long weekend'
  });

  const validationError = document.validateSync();

  assert.ok(validationError);
  assert.ok(validationError.errors.priceAmount);
  assert.ok(validationError.errors.durationNights);
});

test('trip schema defines indexes for uniqueness, filtering, and text search', () => {
  const indexes = Trip.schema.indexes();

  assert.ok(indexes.some(([fields, options]) => fields.code === 1 && options.unique));
  assert.ok(indexes.some(([fields]) => fields.priceAmount === 1 && fields.durationNights === 1));
  assert.ok(indexes.some(([fields]) => fields.searchText === 'text'));
});
