process.env.MONGODB_URI = 'mongodb://127.0.0.1:27017/travlr_test';
process.env.JWT_SECRET = 'unit-test-secret';
process.env.NODE_ENV = 'test';

const test = require('node:test');
const assert = require('node:assert/strict');
const jwt = require('jsonwebtoken');

const { authenticateJWT } = require('../app_api/middleware/authentication');

const createResponse = () => ({
  statusCode: null,
  body: null,
  status(code) {
    this.statusCode = code;
    return this;
  },
  json(body) {
    this.body = body;
    return this;
  }
});

test('authenticateJWT rejects requests without bearer tokens', () => {
  const request = {
    get() {
      return undefined;
    }
  };
  const response = createResponse();
  let nextCalled = false;

  authenticateJWT(request, response, () => {
    nextCalled = true;
  });

  assert.equal(response.statusCode, 401);
  assert.deepEqual(response.body, { message: 'Authentication required' });
  assert.equal(nextCalled, false);
});

test('authenticateJWT accepts valid tokens and attaches verified claims', () => {
  const token = jwt.sign({ email: 'admin@example.com' }, process.env.JWT_SECRET);
  const request = {
    auth: null,
    get() {
      return `Bearer ${token}`;
    }
  };
  const response = createResponse();
  let nextCalled = false;

  authenticateJWT(request, response, () => {
    nextCalled = true;
  });

  assert.equal(nextCalled, true);
  assert.equal(request.auth.email, 'admin@example.com');
});
