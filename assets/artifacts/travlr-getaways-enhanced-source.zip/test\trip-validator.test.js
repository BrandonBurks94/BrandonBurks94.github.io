const test = require('node:test');
const assert = require('node:assert/strict');

const {
  buildTripPayload,
  validateTripPayload,
  validateTripCode
} = require('../app_api/validators/trip-validator');

const validTrip = {
  code: ' GALE-REEF ',
  name: ' Gale Reef ',
  image: 'reef1.jpg',
  duration: '4 nights',
  price: '$799',
  description: 'Featured reef trip',
  details: 'Guided reef travel package'
};

test('validateTripPayload rejects missing or blank fields with a reusable error shape', () => {
  assert.throws(
    () => validateTripPayload({ ...validTrip, price: '   ', details: undefined }),
    (err) => err.statusCode === 400
      && err.message === 'Missing required trip fields'
      && assert.deepEqual(err.details, { fields: ['price', 'details'] }) === undefined
  );
});

test('buildTripPayload trims and allowlists trip fields', () => {
  const payload = buildTripPayload({ ...validTrip, unexpected: 'ignored' });

  assert.deepEqual(payload, {
    code: 'GALE-REEF',
    name: 'Gale Reef',
    image: 'reef1.jpg',
    duration: '4 nights',
    price: '$799',
    description: 'Featured reef trip',
    details: 'Guided reef travel package',
    priceAmount: 799,
    durationNights: 4,
    searchText: 'gale-reef gale reef featured reef trip guided reef travel package'
  });
});

test('validateTripPayload rejects prices and durations that cannot be stored numerically', () => {
  assert.throws(
    () => validateTripPayload({ ...validTrip, price: 'free' }),
    /Trip price must contain a numeric amount/
  );

  assert.throws(
    () => validateTripPayload({ ...validTrip, duration: 'weekend getaway' }),
    /Trip duration must contain a numeric night count/
  );
});

test('validateTripCode trims valid codes and rejects blank codes', () => {
  assert.equal(validateTripCode(' GALE-REEF '), 'GALE-REEF');
  assert.throws(() => validateTripCode(' '), /Trip code is required/);
});
