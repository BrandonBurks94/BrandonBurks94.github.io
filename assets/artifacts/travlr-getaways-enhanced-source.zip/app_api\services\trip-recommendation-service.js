const HttpError = require('../errors/http-error');
const {
  parseMoney,
  parseNights
} = require('../utils/trip-normalization');

const MAX_RESULTS = 10;
const PRICE_WEIGHT = 35;
const DURATION_WEIGHT = 20;
const TEXT_WEIGHT = 8;
const EXACT_CODE_WEIGHT = 15;

const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

const tokenize = (value) => String(value || '')
  .toLowerCase()
  .match(/[a-z0-9]+/g) || [];

const buildSearchIndex = (trips) => trips.reduce((index, trip, position) => {
  const searchableText = [
    trip.code,
    trip.name,
    trip.description,
    trip.details
  ].join(' ');

  new Set(tokenize(searchableText)).forEach((token) => {
    if (!index.has(token)) {
      index.set(token, new Set());
    }
    index.get(token).add(position);
  });

  return index;
}, new Map());

const normalizeCriteria = (criteria = {}) => {
  const maxPrice = parseMoney(criteria.maxPrice);
  const maxNights = parseNights(criteria.maxNights);
  const limit = Number(criteria.limit || MAX_RESULTS);
  const tokens = Array.isArray(criteria.tokens)
    ? criteria.tokens
    : [...new Set(tokenize(criteria.query || criteria.destination || ''))];

  if (criteria.maxPrice !== undefined && maxPrice === null) {
    throw new HttpError(400, 'maxPrice must be a valid number or currency value');
  }

  if (criteria.maxNights !== undefined && maxNights === null) {
    throw new HttpError(400, 'maxNights must be a valid number');
  }

  if (!Number.isInteger(limit) || limit < 1 || limit > MAX_RESULTS) {
    throw new HttpError(400, `limit must be an integer from 1 to ${MAX_RESULTS}`);
  }

  return {
    maxPrice,
    maxNights,
    limit,
    tokens
  };
};

const candidatePositionsForTokens = (index, tokens, tripCount) => {
  if (!tokens.length) {
    return new Set(Array.from({ length: tripCount }, (_, position) => position));
  }

  return tokens.reduce((positions, token) => {
    const matches = index.get(token);
    if (!matches) {
      return positions;
    }

    matches.forEach((position) => positions.add(position));
    return positions;
  }, new Set());
};

const scoreTrip = (trip, criteria, matchedTokens) => {
  const price = parseMoney(trip.priceAmount ?? trip.price);
  const nights = parseNights(trip.durationNights ?? trip.duration);
  let score = 0;
  const reasons = [];

  if (criteria.tokens.length) {
    const textScore = matchedTokens.length * TEXT_WEIGHT;
    score += textScore;
    if (matchedTokens.length) {
      reasons.push(`matched ${matchedTokens.join(', ')}`);
    }

    if (criteria.tokens.includes(String(trip.code || '').toLowerCase())) {
      score += EXACT_CODE_WEIGHT;
      reasons.push('exact trip code match');
    }
  }

  if (criteria.maxPrice !== null && price !== null && price <= criteria.maxPrice) {
    const fit = 1 - (price / criteria.maxPrice);
    const priceScore = Math.round(PRICE_WEIGHT * clamp(fit, 0, 1));
    score += priceScore;
    reasons.push(`within $${criteria.maxPrice} budget`);
  }

  if (criteria.maxNights !== null && nights !== null && nights <= criteria.maxNights) {
    const fit = 1 - (nights / criteria.maxNights);
    const durationScore = Math.round(DURATION_WEIGHT * clamp(fit, 0, 1));
    score += durationScore;
    reasons.push(`within ${criteria.maxNights} night limit`);
  }

  return {
    score,
    reasons: reasons.length ? reasons : ['included as an available trip option']
  };
};

const createTripRecommendationService = () => ({
  normalizeCriteria,

  recommend(trips, rawCriteria = {}) {
    if (!Array.isArray(trips)) {
      throw new HttpError(500, 'Trip recommendations require a trip collection');
    }

    const criteria = normalizeCriteria(rawCriteria);
    const index = buildSearchIndex(trips);
    const candidatePositions = candidatePositionsForTokens(index, criteria.tokens, trips.length);

    return [...candidatePositions]
      .map((position) => {
        const trip = trips[position];
        const tripTokens = new Set(tokenize([
          trip.code,
          trip.name,
          trip.description,
          trip.details
        ].join(' ')));
        const matchedTokens = criteria.tokens.filter((token) => tripTokens.has(token));
        const { score, reasons } = scoreTrip(trip, criteria, matchedTokens);

        return {
          ...trip,
          recommendationScore: score,
          recommendationReasons: reasons,
          _position: position
        };
      })
      .filter((trip) => {
        const price = parseMoney(trip.priceAmount ?? trip.price);
        const nights = parseNights(trip.durationNights ?? trip.duration);
        const matchesPrice = criteria.maxPrice === null || price === null || price <= criteria.maxPrice;
        const matchesDuration = criteria.maxNights === null || nights === null || nights <= criteria.maxNights;
        const matchesText = !criteria.tokens.length || trip.recommendationScore > 0;
        return matchesPrice && matchesDuration && matchesText;
      })
      .sort((left, right) => {
        if (right.recommendationScore !== left.recommendationScore) {
          return right.recommendationScore - left.recommendationScore;
        }

        const leftPrice = parseMoney(left.priceAmount ?? left.price) ?? Number.POSITIVE_INFINITY;
        const rightPrice = parseMoney(right.priceAmount ?? right.price) ?? Number.POSITIVE_INFINITY;
        if (leftPrice !== rightPrice) {
          return leftPrice - rightPrice;
        }

        return left._position - right._position;
      })
      .slice(0, criteria.limit)
      .map(({ _position, ...trip }) => trip);
  }
});

module.exports = {
  createTripRecommendationService,
  parseMoney,
  parseNights,
  tokenize,
  buildSearchIndex,
  normalizeCriteria
};
