const jwt = require('jsonwebtoken');
const { config } = require('../config/environment');

const authenticateJWT = (req, res, next) => {
  const authHeader = req.get('authorization');

  if (!authHeader) {
    return res.status(401).json({ message: 'Authentication required' });
  }

  const [scheme, token] = authHeader.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Invalid authorization header' });
  }

  return jwt.verify(token, config.jwtSecret, (err, verified) => {
    if (err) {
      return res.status(401).json({ message: 'Invalid or expired token' });
    }

    req.auth = verified;
    return next();
  });
};

module.exports = {
  authenticateJWT
};
