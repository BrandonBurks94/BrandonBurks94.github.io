const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const { config } = require('../config/environment');

const SCRYPT_KEY_LENGTH = 64;

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true,
    required: true,
    trim: true,
    lowercase: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  hash: String,
  salt: String
});

userSchema.methods.setPassword = function setPassword(password) {
  this.salt = crypto.randomBytes(16).toString('hex');
  this.hash = crypto.scryptSync(password, this.salt, SCRYPT_KEY_LENGTH).toString('hex');
};

userSchema.methods.validPassword = function validPassword(password) {
  const storedHash = Buffer.from(this.hash, 'hex');
  const hash = crypto.scryptSync(password, this.salt, SCRYPT_KEY_LENGTH);

  return storedHash.length === hash.length && crypto.timingSafeEqual(storedHash, hash);
};

userSchema.methods.generateJWT = function generateJWT() {
  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      name: this.name
    },
    config.jwtSecret,
    { expiresIn: config.jwtExpiresIn }
  );
};

const User = mongoose.model('users', userSchema);

module.exports = User;
