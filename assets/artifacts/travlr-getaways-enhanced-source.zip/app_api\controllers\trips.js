const asyncHandler = require('../middleware/async-handler');
const createTripService = require('../services/trip-service');

const tripService = createTripService();

const tripsList = asyncHandler(async (req, res) => {
  const trips = await tripService.listTrips();
  res.status(200).json(trips);
});

const tripsRecommend = asyncHandler(async (req, res) => {
  const trips = await tripService.recommendTrips(req.query);
  res.status(200).json(trips);
});

const tripsFindByCode = asyncHandler(async (req, res) => {
  const trip = await tripService.getTripByCode(req.params.tripCode);
  res.status(200).json(trip);
});

const tripsAddTrip = asyncHandler(async (req, res) => {
  const trip = await tripService.addTrip(req.body);
  res.status(201).json(trip);
});

const tripsUpdateTrip = asyncHandler(async (req, res) => {
  const trip = await tripService.updateTrip(req.params.tripCode, req.body);
  res.status(200).json(trip);
});

const tripsDeleteTrip = asyncHandler(async (req, res) => {
  await tripService.deleteTrip(req.params.tripCode);
  res.status(204).send();
});

module.exports = {
  tripsList,
  tripsRecommend,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};
