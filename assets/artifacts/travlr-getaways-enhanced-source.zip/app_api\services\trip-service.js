const HttpError = require('../errors/http-error');
const {
  buildTripPayload,
  validateTripPayload,
  validateTripCode
} = require('../validators/trip-validator');
const { createTripRecommendationService } = require('./trip-recommendation-service');

const isDuplicateKeyError = (err) => err && err.code === 11000;

const getDefaultRepository = () => require('../repositories/trip-repository');

const createTripService = (
  repository = getDefaultRepository(),
  recommendationService = createTripRecommendationService()
) => ({
  async listTrips() {
    return repository.findAll();
  },

  async recommendTrips(criteria) {
    const normalizedCriteria = recommendationService.normalizeCriteria
      ? recommendationService.normalizeCriteria(criteria)
      : criteria;
    const trips = repository.findForRecommendationCriteria
      ? await repository.findForRecommendationCriteria(normalizedCriteria)
      : await repository.findAll();
    return recommendationService.recommend(trips, normalizedCriteria);
  },

  async getTripByCode(tripCode) {
    const code = validateTripCode(tripCode);
    const trip = await repository.findByCode(code);

    if (!trip) {
      throw new HttpError(404, `Trip code ${code} not found`);
    }

    return trip;
  },

  async addTrip(body) {
    validateTripPayload(body);

    try {
      return await repository.create(buildTripPayload(body));
    } catch (err) {
      if (isDuplicateKeyError(err)) {
        throw new HttpError(409, `Trip code ${body.code} already exists`);
      }

      throw err;
    }
  },

  async updateTrip(tripCode, body) {
    const code = validateTripCode(tripCode);
    validateTripPayload(body);

    try {
      const trip = await repository.updateByCode(code, buildTripPayload(body));

      if (!trip) {
        throw new HttpError(404, `Trip code ${code} not found`);
      }

      return trip;
    } catch (err) {
      if (isDuplicateKeyError(err)) {
        throw new HttpError(409, `Trip code ${body.code} already exists`);
      }

      throw err;
    }
  },

  async deleteTrip(tripCode) {
    const code = validateTripCode(tripCode);
    const trip = await repository.deleteByCode(code);

    if (!trip) {
      throw new HttpError(404, `Trip code ${code} not found`);
    }
  }
});

module.exports = createTripService;
