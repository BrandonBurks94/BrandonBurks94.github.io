const test = require('node:test');
const assert = require('node:assert/strict');

process.env.MONGODB_URI = 'mongodb://127.0.0.1:27017/travlr_test';
process.env.JWT_SECRET = 'unit-test-secret';
process.env.NODE_ENV = 'test';

const { validateEnvironment } = require('../app_api/config/environment');

test('validateEnvironment fails fast when required configuration is missing', () => {
  assert.throws(
    () => validateEnvironment({}),
    /MONGODB_URI, JWT_SECRET/
  );
});

test('validateEnvironment returns normalized application configuration', () => {
  const config = validateEnvironment({
    MONGODB_URI: 'mongodb://127.0.0.1:27017/travlr_test',
    JWT_SECRET: 'test-secret',
    JWT_EXPIRES_IN: '15m',
    NODE_ENV: 'test'
  });

  assert.deepEqual(config, {
    mongodbUri: 'mongodb://127.0.0.1:27017/travlr_test',
    jwtSecret: 'test-secret',
    jwtExpiresIn: '15m',
    nodeEnv: 'test'
  });
});
