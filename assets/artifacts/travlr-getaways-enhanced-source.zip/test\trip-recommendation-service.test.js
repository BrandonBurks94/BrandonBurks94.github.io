const test = require('node:test');
const assert = require('node:assert/strict');

const {
  createTripRecommendationService,
  parseMoney,
  parseNights,
  buildSearchIndex
} = require('../app_api/services/trip-recommendation-service');

const trips = [
  {
    code: 'GALE-REEF',
    name: 'Gale Reef',
    image: 'reef1.jpg',
    duration: '4 nights',
    price: '$799',
    description: 'Guided reef trip with beginner snorkeling',
    details: 'Calm water reef package'
  },
  {
    code: 'DAWSON-REEF',
    name: "Dawson's Reef",
    image: 'reef2.jpg',
    duration: '6 nights',
    price: '$1199',
    description: 'Premium reef trip with advanced diving',
    details: 'Extended reef package'
  },
  {
    code: 'CITY-WALK',
    name: 'City Walk',
    image: 'city.jpg',
    duration: '2 nights',
    price: '$499',
    description: 'Urban food and museum weekend',
    details: 'Walkable city package'
  }
];

test('parses price and duration fields from display strings', () => {
  assert.equal(parseMoney('$1,199'), 1199);
  assert.equal(parseMoney('799'), 799);
  assert.equal(parseNights('4 nights'), 4);
  assert.equal(parseNights('2-day trip'), 2);
});

test('builds an inverted search index from searchable trip fields', () => {
  const index = buildSearchIndex(trips);

  assert.deepEqual([...index.get('reef')].sort(), [0, 1]);
  assert.deepEqual([...index.get('urban')], [2]);
});

test('recommendations filter trips by text, budget, and duration constraints', () => {
  const service = createTripRecommendationService();

  const results = service.recommend(trips, {
    query: 'reef',
    maxPrice: '$900',
    maxNights: '4',
    limit: '5'
  });

  assert.equal(results.length, 1);
  assert.equal(results[0].code, 'GALE-REEF');
  assert.ok(results[0].recommendationScore > 0);
  assert.ok(results[0].recommendationReasons.some((reason) => reason.includes('reef')));
});

test('recommendations use score, price, and original order as stable tie-breakers', () => {
  const service = createTripRecommendationService();

  const results = service.recommend(trips, {
    query: 'package',
    maxNights: '10'
  });

  assert.deepEqual(results.map((trip) => trip.code), [
    'CITY-WALK',
    'GALE-REEF',
    'DAWSON-REEF'
  ]);
});

test('recommendations validate query options before ranking', () => {
  const service = createTripRecommendationService();

  assert.throws(
    () => service.recommend(trips, { maxPrice: 'not-a-price' }),
    (err) => err.statusCode === 400 && /maxPrice/.test(err.message)
  );

  assert.throws(
    () => service.recommend(trips, { limit: '99' }),
    (err) => err.statusCode === 400 && /limit/.test(err.message)
  );
});
