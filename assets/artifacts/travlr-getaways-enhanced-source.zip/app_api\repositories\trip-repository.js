const mongoose = require('mongoose');
const {
  parseMoney,
  parseNights
} = require('../utils/trip-normalization');

const Trip = mongoose.model('trips');

const findAll = () => Trip.find({}).lean();

const findByCode = (code) => Trip.findOne({ code }).lean();

const findForRecommendationCriteria = (criteria = {}) => {
  const query = {};
  const sort = {};
  const maxPrice = parseMoney(criteria.maxPrice);
  const maxNights = parseNights(criteria.maxNights);
  const search = (criteria.tokens || []).join(' ').trim();

  if (maxPrice !== null) {
    query.priceAmount = { $lte: maxPrice };
    sort.priceAmount = 1;
  }

  if (maxNights !== null) {
    query.durationNights = { $lte: maxNights };
    sort.durationNights = 1;
  }

  if (search) {
    query.$text = { $search: search };
    sort.score = { $meta: 'textScore' };
  }

  const resultLimit = Math.max(Number(criteria.limit || 10) * 3, 10);

  return Trip.find(query)
    .sort(Object.keys(sort).length ? sort : { code: 1 })
    .limit(resultLimit)
    .lean();
};

const create = (payload) => Trip.create(payload);

const updateByCode = (code, payload) => Trip.findOneAndUpdate(
  { code },
  payload,
  { returnDocument: 'after', runValidators: true }
).lean();

const deleteByCode = (code) => Trip.findOneAndDelete({ code }).lean();

module.exports = {
  findAll,
  findByCode,
  findForRecommendationCriteria,
  create,
  updateByCode,
  deleteByCode
};
