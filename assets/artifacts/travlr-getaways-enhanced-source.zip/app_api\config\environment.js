const requiredVariables = ['MONGODB_URI', 'JWT_SECRET'];

const validateEnvironment = (env = process.env) => {
  const missing = requiredVariables.filter((key) => !env[key] || !env[key].trim());

  if (missing.length) {
    throw new Error(`Missing required environment variable(s): ${missing.join(', ')}`);
  }

  return {
    mongodbUri: env.MONGODB_URI,
    jwtSecret: env.JWT_SECRET,
    jwtExpiresIn: env.JWT_EXPIRES_IN || '1h',
    nodeEnv: env.NODE_ENV || 'development'
  };
};

module.exports = {
  validateEnvironment,
  config: validateEnvironment()
};
