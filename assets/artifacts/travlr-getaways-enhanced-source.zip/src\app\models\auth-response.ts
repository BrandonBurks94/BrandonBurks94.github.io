export class AuthResponse {
  token = '';
}
