const passport = require('passport');
const User = require('../models/user');
const asyncHandler = require('../middleware/async-handler');
const HttpError = require('../errors/http-error');

const register = asyncHandler(async (req, res) => {
  if (!req.body.name || !req.body.email || !req.body.password) {
    throw new HttpError(400, 'All fields required');
  }

  try {
    const user = new User();

    user.name = req.body.name;
    user.email = req.body.email;
    user.setPassword(req.body.password);

    await user.save();

    const token = user.generateJWT();

    return res.status(200).json({ token });
  } catch (err) {
    if (err.code === 11000) {
      throw new HttpError(409, 'User already exists');
    }

    throw err;
  }
});

const login = (req, res, next) => {
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'All fields required' });
  }

  return passport.authenticate('local', (err, user, info) => {
    if (err) {
      return next(err);
    }

    if (user) {
      const token = user.generateJWT();
      return res.status(200).json({ token });
    }

    return res.status(401).json({ message: info?.message || 'Invalid credentials' });
  })(req, res);
};

module.exports = {
  register,
  login
};
