const notFoundHandler = (req, res) => {
  res.status(404).json({ message: 'Resource not found' });
};

const errorHandler = (err, req, res, next) => {
  if (res.headersSent) {
    return next(err);
  }

  const statusCode = Number.isInteger(err.statusCode) ? err.statusCode : 500;
  const response = {
    message: statusCode >= 500 ? 'An unexpected server error occurred' : err.message
  };

  if (err.details) {
    response.details = err.details;
  }

  if (statusCode >= 500) {
    console.error(err);
  }

  return res.status(statusCode).json(response);
};

module.exports = {
  notFoundHandler,
  errorHandler
};
